import type { Config } from "tailwindcss";

export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      fontFamily: {
        sans: ["Inter", "sans-serif"],
        display: ["Outfit", "sans-serif"],
      },
      colors: {
        neon: {
          purple: "#a855f7",
          cyan: "#22d3ee",
          lime: "#a3e635",
        },
      },
    },
  },
  plugins: [],
} satisfies Config;
