export type GameCategory = "mobile" | "pc" | "console" | "voucher";

export interface Game {
  name: string;
  category: GameCategory;
  currency: string;
  startingPrice: number;
  gradient: string;
  shortLabel: string;
  badge?: { text: string; className: string };
}

export interface AmountOption {
  label: string;
  price: number;
  badge?: string;
}

export interface PaymentMethod {
  name: string;
  label: string;
  icon: string;
  group: "E-Wallet" | "Virtual Account";
}

export interface FAQItem {
  question: string;
  answer: string;
}

export interface Testimonial {
  name: string;
  game: string;
  avatar: string;
  avatarBg: string;
  message: string;
}

export interface CheckoutState {
  game: string;
  userId: string;
  zoneId: string;
  amount: string | null;
  price: number;
  payment: string | null;
  whatsapp: string;
  orderId: string;
}

export interface ToastState {
  message: string;
  visible: boolean;
}
