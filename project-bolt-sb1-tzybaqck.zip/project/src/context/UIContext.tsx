import { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from "react";
import type { ToastState } from "@/types";

interface UIContextValue {
  toast: ToastState;
  showToast: (message: string) => void;
  checkoutGame: string | null;
  openCheckout: (game: string) => void;
  closeCheckout: () => void;
  trackerOpen: boolean;
  openTracker: () => void;
  closeTracker: () => void;
}

const UIContext = createContext<UIContextValue | null>(null);

export function UIProvider({ children }: { children: ReactNode }) {
  const [toast, setToast] = useState<ToastState>({ message: "", visible: false });
  const [checkoutGame, setCheckoutGame] = useState<string | null>(null);
  const [trackerOpen, setTrackerOpen] = useState(false);

  const showToast = useCallback((message: string) => {
    setToast({ message, visible: true });
    setTimeout(() => setToast((prev) => ({ ...prev, visible: false })), 2800);
  }, []);

  const openCheckout = useCallback((game: string) => {
    setCheckoutGame(game);
  }, []);

  const closeCheckout = useCallback(() => {
    setCheckoutGame(null);
  }, []);

  const openTracker = useCallback(() => {
    setTrackerOpen(true);
  }, []);

  const closeTracker = useCallback(() => {
    setTrackerOpen(false);
  }, []);

  const value = useMemo(
    () => ({ toast, showToast, checkoutGame, openCheckout, closeCheckout, trackerOpen, openTracker, closeTracker }),
    [toast, showToast, checkoutGame, openCheckout, closeCheckout, trackerOpen, openTracker, closeTracker],
  );

  return <UIContext.Provider value={value}>{children}</UIContext.Provider>;
}

export function useUI(): UIContextValue {
  const ctx = useContext(UIContext);
  if (!ctx) throw new Error("useUI must be used within UIProvider");
  return ctx;
}
