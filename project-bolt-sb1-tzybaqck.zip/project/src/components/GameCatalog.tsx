import { useState } from "react";
import { games, gameFilters } from "@/data";
import type { GameCategory } from "@/types";
import { formatRupiah } from "@/utils";
import { useUI } from "@/context/UIContext";

export function GameCatalog() {
  const { openCheckout } = useUI();
  const [filter, setFilter] = useState<string>("all");

  const filteredGames = filter === "all" ? games : games.filter((g) => g.category === filter);

  return (
    <section id="games" className="mx-auto max-w-7xl px-5 py-20 lg:px-8">
      <div className="flex flex-col justify-between gap-5 sm:flex-row sm:items-end">
        <div>
          <p className="text-sm font-bold uppercase tracking-widest text-purple-400">Game Catalog</p>
          <h2 className="font-display mt-2 text-4xl font-extrabold">Mau Main Apa Hari Ini?</h2>
          <p className="mt-3 text-white/40">Pilih game → masukin ID → pilih nominal → gas.</p>
        </div>

        <div className="flex flex-wrap gap-2">
          {gameFilters.map((f) => (
            <button
              key={f.value}
              onClick={() => setFilter(f.value)}
              className={`rounded-xl px-4 py-2 text-sm transition ${
                filter === f.value
                  ? "bg-purple-500 font-bold"
                  : "border border-white/10 bg-white/[0.03] font-semibold text-white/60"
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {filteredGames.map((game) => (
          <GameCard key={game.name} game={game} onTopUp={() => openCheckout(game.name)} />
        ))}
      </div>
    </section>
  );
}

function GameCard({ game, onTopUp }: { game: (typeof games)[number]; onTopUp: () => void }) {
  return (
    <article className="game-card glass card-hover overflow-hidden rounded-3xl">
      <div className={`relative aspect-[4/3] overflow-hidden bg-gradient-to-br ${game.gradient}`}>
        <div className="absolute inset-0 flex items-center justify-center">
          <span className="font-display text-5xl font-extrabold text-white/10">{game.shortLabel}</span>
        </div>
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
        {game.badge && (
          <span
            className={`absolute left-4 top-4 rounded-full px-3 py-1 text-xs font-bold ${game.badge.className}`}
          >
            {game.badge.text}
          </span>
        )}
      </div>

      <div className="p-5">
        <h3 className="font-display text-xl font-bold">{game.name}</h3>
        <p className="mt-1 text-sm text-white/40">{game.currency}</p>
        <div className="mt-5 flex items-center justify-between">
          <div>
            <p className="text-xs text-white/30">Mulai dari</p>
            <p className="font-bold text-purple-300">{formatRupiah(game.startingPrice)}</p>
          </div>
          <button
            onClick={onTopUp}
            className="rounded-xl bg-white px-4 py-2 text-sm font-bold text-black transition hover:bg-purple-300"
          >
            Top Up →
          </button>
        </div>
      </div>
    </article>
  );
}
