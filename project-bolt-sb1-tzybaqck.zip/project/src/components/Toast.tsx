import { useUI } from "@/context/UIContext";

export function Toast() {
  const { toast } = useUI();

  return (
    <div
      className={`toast fixed bottom-5 left-1/2 z-[100] -translate-x-1/2 rounded-2xl border border-white/10 bg-[#15131d] px-5 py-3 text-sm font-semibold shadow-2xl ${
        toast.visible ? "show" : ""
      }`}
    >
      <span>{toast.message}</span>
    </div>
  );
}
