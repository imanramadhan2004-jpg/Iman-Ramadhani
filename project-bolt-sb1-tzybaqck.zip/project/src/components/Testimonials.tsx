import { testimonials } from "@/data";

export function Testimonials() {
  return (
    <section className="mx-auto max-w-7xl px-5 py-20 lg:px-8">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
        <div>
          <p className="text-sm font-bold uppercase tracking-widest text-purple-400">Community</p>
          <h2 className="font-display mt-2 text-4xl font-extrabold">Mereka Udah Gas Duluan.</h2>
        </div>
        <div className="text-sm text-white/40">★★★★★ 4.9/5 dari 12K+ transaksi</div>
      </div>

      <div className="mt-10 grid gap-5 md:grid-cols-3">
        {testimonials.map((t) => (
          <div key={t.name} className="glass rounded-3xl p-6">
            <div className="flex items-center gap-3">
              <div className={`flex h-10 w-10 items-center justify-center rounded-full ${t.avatarBg} font-bold`}>
                {t.avatar}
              </div>
              <div>
                <p className="font-semibold">{t.name}</p>
                <p className="text-xs text-white/30">{t.game}</p>
              </div>
            </div>
            <p className="mt-5 leading-7 text-white/60">"{t.message}"</p>
            <div className="mt-5 text-yellow-300">★★★★★</div>
          </div>
        ))}
      </div>
    </section>
  );
}
