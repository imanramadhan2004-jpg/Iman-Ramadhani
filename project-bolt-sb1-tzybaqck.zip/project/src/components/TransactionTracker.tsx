import { useState } from "react";
import { useUI } from "@/context/UIContext";

export function TransactionTracker() {
  const { trackerOpen, closeTracker, showToast } = useUI();
  const [input, setInput] = useState("");
  const [showResult, setShowResult] = useState(false);

  const handleTrack = () => {
    if (!input.trim()) {
      showToast("Masukkan Order ID terlebih dahulu.");
      return;
    }
    setShowResult(true);
    showToast("Transaksi ditemukan ⚡");
  };

  const handleClose = () => {
    closeTracker();
    setShowResult(false);
    setInput("");
  };

  return (
    <div
      className={`modal-overlay fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-md ${
        trackerOpen ? "active" : ""
      }`}
      onClick={(e) => {
        if (e.target === e.currentTarget) handleClose();
      }}
    >
      <div className="modal-panel w-full max-w-lg rounded-3xl border border-white/10 bg-[#0d0c14] p-6 shadow-2xl">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-xs font-bold uppercase tracking-widest text-purple-400">Transaction</p>
            <h2 className="font-display text-2xl font-bold">Cek Status</h2>
          </div>
          <button
            onClick={handleClose}
            className="flex h-10 w-10 items-center justify-center rounded-xl bg-white/5"
          >
            ✕
          </button>
        </div>

        <div className="mt-7">
          <input
            type="text"
            placeholder="Contoh: NX-8F3A21"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            className="w-full rounded-xl border border-white/10 bg-white/[0.04] px-4 py-3 outline-none focus:border-purple-400"
          />
          <button
            onClick={handleTrack}
            className="mt-3 w-full rounded-xl bg-purple-500 px-5 py-3 font-bold transition hover:bg-purple-400"
          >
            Cek Transaksi
          </button>
        </div>

        {showResult && (
          <div className="mt-7">
            <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-5">
              <div className="flex items-center justify-between">
                <span className="text-sm text-white/40">Status</span>
                <span className="rounded-full bg-lime-400/10 px-3 py-1 text-xs font-bold text-lime-300">
                  PROCESSING
                </span>
              </div>
              <div className="mt-7 space-y-6">
                <div className="flex gap-4">
                  <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-lime-400/15 text-lime-300">
                    ✓
                  </div>
                  <div>
                    <p className="font-semibold">Pembayaran diterima</p>
                    <p className="mt-1 text-xs text-white/30">Order berhasil dibuat.</p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-purple-400/15 text-purple-300">
                    ⚡
                  </div>
                  <div>
                    <p className="font-semibold">Processing</p>
                    <p className="mt-1 text-xs text-white/30">Item sedang dikirim ke akun.</p>
                  </div>
                </div>
                <div className="flex gap-4 opacity-30">
                  <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full border border-white/10">
                    3
                  </div>
                  <div>
                    <p className="font-semibold">Selesai</p>
                    <p className="mt-1 text-xs">Menunggu proses sebelumnya.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
