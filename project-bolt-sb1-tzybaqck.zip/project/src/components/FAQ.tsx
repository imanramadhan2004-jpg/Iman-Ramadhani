import { useState } from "react";
import { faqItems } from "@/data";

export function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  return (
    <section id="faq" className="mx-auto max-w-4xl px-5 py-20 lg:px-8">
      <div className="text-center">
        <p className="text-sm font-bold uppercase tracking-widest text-purple-400">FAQ</p>
        <h2 className="font-display mt-2 text-4xl font-extrabold">Masih Bingung?</h2>
      </div>

      <div className="mt-10 space-y-3">
        {faqItems.map((item, index) => {
          const isOpen = openIndex === index;
          return (
            <div key={index} className="faq-item glass overflow-hidden rounded-2xl">
              <button
                onClick={() => setOpenIndex(isOpen ? null : index)}
                className="flex w-full items-center justify-between p-5 text-left font-semibold"
              >
                <span>{item.question}</span>
                <span className="text-xl text-purple-400">{isOpen ? "−" : "+"}</span>
              </button>
              {isOpen && <div className="px-5 pb-5 text-sm leading-7 text-white/45">{item.answer}</div>}
            </div>
          );
        })}
      </div>
    </section>
  );
}
