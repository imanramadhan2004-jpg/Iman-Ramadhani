import { useEffect, useState } from "react";
import { useUI } from "@/context/UIContext";
import { amountOptions, paymentMethods } from "@/data";
import { formatRupiah, generateOrderId } from "@/utils";

export function CheckoutModal() {
  const { checkoutGame, closeCheckout, showToast, openTracker } = useUI();

  const [step, setStep] = useState(1);
  const [userId, setUserId] = useState("");
  const [zoneId, setZoneId] = useState("");
  const [whatsapp, setWhatsapp] = useState("");
  const [selectedAmount, setSelectedAmount] = useState<string | null>(null);
  const [selectedPrice, setSelectedPrice] = useState(0);
  const [selectedPayment, setSelectedPayment] = useState<string | null>(null);
  const [validating, setValidating] = useState(false);
  const [validated, setValidated] = useState(false);
  const [orderId, setOrderId] = useState("");
  const [showSuccess, setShowSuccess] = useState(false);

  useEffect(() => {
    if (checkoutGame) {
      setStep(1);
      setUserId("");
      setZoneId("");
      setWhatsapp("");
      setSelectedAmount(null);
      setSelectedPrice(0);
      setSelectedPayment(null);
      setValidated(false);
      setShowSuccess(false);
      setOrderId("");
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => {
      document.body.style.overflow = "";
    };
  }, [checkoutGame]);

  useEffect(() => {
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === "Escape") closeCheckout();
    };
    document.addEventListener("keydown", handleEsc);
    return () => document.removeEventListener("keydown", handleEsc);
  }, [closeCheckout]);

  if (!checkoutGame) return null;

  const validatePlayer = () => {
    if (!userId.trim() || !zoneId.trim()) {
      showToast("Isi User ID dan Zone ID dulu ya 👀");
      return;
    }
    setValidating(true);
    setTimeout(() => {
      setValidating(false);
      setValidated(true);
      showToast("Player berhasil ditemukan ✓");
    }, 1000);
  };

  const nextStep = (target: number) => {
    if (target === 2 && (!userId.trim() || !zoneId.trim())) {
      showToast("Masukkan Player ID dulu ya.");
      return;
    }
    if (target === 3 && !selectedAmount) {
      showToast("Pilih nominal terlebih dahulu.");
      return;
    }
    if (target === 4 && !selectedPayment) {
      showToast("Pilih metode pembayaran.");
      return;
    }
    setStep(target);
  };

  const selectAmount = (amount: string, price: number) => {
    setSelectedAmount(amount);
    setSelectedPrice(price);
  };

  const selectPayment = (payment: string) => {
    setSelectedPayment(payment);
  };

  const submitOrder = () => {
    if (!whatsapp.trim()) {
      showToast("Masukkan nomor WhatsApp dulu.");
      return;
    }
    if (whatsapp.trim().length < 9) {
      showToast("Nomor WhatsApp belum valid.");
      return;
    }
    const id = generateOrderId();
    setOrderId(id);
    setShowSuccess(true);
    showToast("Order berhasil dibuat 🎉");
  };

  const handleClose = () => {
    closeCheckout();
  };

  const handleSuccessClose = () => {
    closeCheckout();
    openTracker();
  };

  const total = selectedPrice + 1000;

  const stepIndicators = [1, 2, 3, 4];

  return (
    <div
      className="modal-overlay fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-md active"
      onClick={(e) => {
        if (e.target === e.currentTarget) handleClose();
      }}
    >
      <div className="modal-panel max-h-[92vh] w-full max-w-2xl overflow-y-auto rounded-3xl border border-white/10 bg-[#0d0c14] shadow-2xl">
        {/* Header */}
        <div className="sticky top-0 z-10 flex items-center justify-between border-b border-white/5 bg-[#0d0c14]/95 p-5 backdrop-blur-xl">
          <div>
            <p className="text-xs font-bold uppercase tracking-widest text-purple-400">Checkout</p>
            <h2 className="font-display text-2xl font-bold">{checkoutGame}</h2>
          </div>
          <button
            onClick={handleClose}
            className="flex h-10 w-10 items-center justify-center rounded-xl bg-white/5 text-white/60 transition hover:bg-white/10 hover:text-white"
          >
            ✕
          </button>
        </div>

        {/* Step Indicators */}
        <div className="flex gap-2 border-b border-white/5 p-5">
          {stepIndicators.map((s, i) => (
            <div key={s} className="flex items-center gap-2 flex-1">
              <div
                className={`step-indicator flex h-9 w-9 shrink-0 items-center justify-center rounded-full border text-sm font-bold ${
                  s < step
                    ? "done"
                    : s === step
                      ? "active"
                      : "border-white/10 text-white/40"
                }`}
              >
                {s}
              </div>
              {i < 3 && <div className="h-px flex-1 bg-white/10" />}
            </div>
          ))}
        </div>

        <div className="p-5 sm:p-7">
          {/* STEP 1: Player ID */}
          {!showSuccess && step === 1 && (
            <div>
              <h3 className="font-display text-2xl font-bold">Player ID</h3>
              <p className="mt-2 text-sm text-white/40">Masukkan ID game kamu. Jangan sampai typo ya 👀</p>
              <div className="mt-7 space-y-4">
                <div>
                  <label className="mb-2 block text-sm font-semibold">User ID</label>
                  <input
                    type="text"
                    placeholder="Contoh: 123456789"
                    value={userId}
                    onChange={(e) => setUserId(e.target.value)}
                    className="w-full rounded-xl border border-white/10 bg-white/[0.04] px-4 py-3 outline-none transition focus:border-purple-400"
                  />
                </div>
                <div>
                  <label className="mb-2 block text-sm font-semibold">Zone ID / Server</label>
                  <input
                    type="text"
                    placeholder="Contoh: 1234"
                    value={zoneId}
                    onChange={(e) => setZoneId(e.target.value)}
                    className="w-full rounded-xl border border-white/10 bg-white/[0.04] px-4 py-3 outline-none transition focus:border-purple-400"
                  />
                </div>
                <button
                  onClick={validatePlayer}
                  disabled={validating}
                  className="flex w-full items-center justify-center gap-2 rounded-xl bg-purple-500 px-5 py-3 font-bold transition hover:bg-purple-400 disabled:opacity-70"
                >
                  {validating ? (
                    <>
                      <span className="loading-spinner" />
                      <span>Checking...</span>
                    </>
                  ) : validated ? (
                    <span>✓ ID Valid</span>
                  ) : (
                    <span>✓ Validasi ID</span>
                  )}
                </button>
                {validated && (
                  <div className="rounded-xl border border-lime-400/20 bg-lime-400/5 p-4 text-sm text-lime-300">
                    <div className="font-bold">🟢 Player ditemukan!</div>
                    <div className="mt-1 text-xs text-lime-300/60">
                      Player ID: {userId} · Zone: {zoneId}
                    </div>
                  </div>
                )}
              </div>
              <button
                onClick={() => nextStep(2)}
                className="mt-7 w-full rounded-xl bg-white px-5 py-3 font-bold text-black transition hover:bg-purple-300"
              >
                Lanjut →
              </button>
            </div>
          )}

          {/* STEP 2: Select Amount */}
          {!showSuccess && step === 2 && (
            <div>
              <h3 className="font-display text-2xl font-bold">Pilih Nominal</h3>
              <p className="mt-2 text-sm text-white/40">Pilih item yang mau kamu checkout.</p>
              <div className="mt-7 grid grid-cols-2 gap-3 sm:grid-cols-3">
                {amountOptions.map((opt) => (
                  <button
                    key={opt.label}
                    onClick={() => selectAmount(opt.label, opt.price)}
                    className={`amount-option rounded-2xl border border-white/10 bg-white/[0.03] p-4 text-left transition hover:border-purple-400/40 ${
                      selectedAmount === opt.label ? "selected" : ""
                    }`}
                  >
                    {opt.badge && (
                      <span className="mb-2 inline-block rounded-full bg-orange-400 px-2 py-1 text-[10px] font-bold text-black">
                        {opt.badge}
                      </span>
                    )}
                    <p className="font-bold">{opt.label}</p>
                    <p className="mt-2 text-sm text-purple-300">{formatRupiah(opt.price)}</p>
                  </button>
                ))}
              </div>
              <div className="mt-7 flex gap-3">
                <button
                  onClick={() => setStep(1)}
                  className="w-1/3 rounded-xl border border-white/10 bg-white/5 px-5 py-3 font-bold"
                >
                  ← Back
                </button>
                <button
                  onClick={() => nextStep(3)}
                  className="flex-1 rounded-xl bg-white px-5 py-3 font-bold text-black"
                >
                  Lanjut →
                </button>
              </div>
            </div>
          )}

          {/* STEP 3: Payment */}
          {!showSuccess && step === 3 && (
            <div>
              <h3 className="font-display text-2xl font-bold">Pilih Pembayaran</h3>
              <p className="mt-2 text-sm text-white/40">Bayar pakai metode yang paling nyaman.</p>
              <p className="mt-7 text-xs font-bold uppercase tracking-widest text-white/30">E-Wallet</p>
              <div className="mt-3 grid grid-cols-2 gap-3">
                {paymentMethods
                  .filter((p) => p.group === "E-Wallet")
                  .map((p) => (
                    <button
                      key={p.name}
                      onClick={() => selectPayment(p.name)}
                      className={`payment-option rounded-xl border border-white/10 bg-white/[0.03] p-4 text-left font-bold transition ${
                        selectedPayment === p.name ? "selected" : ""
                      }`}
                    >
                      {p.icon} {p.label}
                    </button>
                  ))}
              </div>
              <p className="mt-7 text-xs font-bold uppercase tracking-widest text-white/30">Virtual Account</p>
              <div className="mt-3 grid grid-cols-2 gap-3">
                {paymentMethods
                  .filter((p) => p.group === "Virtual Account")
                  .map((p) => (
                    <button
                      key={p.name}
                      onClick={() => selectPayment(p.name)}
                      className={`payment-option rounded-xl border border-white/10 bg-white/[0.03] p-4 text-left font-bold transition ${
                        selectedPayment === p.name ? "selected" : ""
                      }`}
                    >
                      {p.icon} {p.label}
                    </button>
                  ))}
              </div>
              <div className="mt-7 flex gap-3">
                <button
                  onClick={() => setStep(2)}
                  className="w-1/3 rounded-xl border border-white/10 bg-white/5 px-5 py-3 font-bold"
                >
                  ← Back
                </button>
                <button
                  onClick={() => nextStep(4)}
                  className="flex-1 rounded-xl bg-white px-5 py-3 font-bold text-black"
                >
                  Lanjut →
                </button>
              </div>
            </div>
          )}

          {/* STEP 4: Summary */}
          {!showSuccess && step === 4 && (
            <div>
              <h3 className="font-display text-2xl font-bold">Hampir Selesai ⚡</h3>
              <p className="mt-2 text-sm text-white/40">Masukkan WhatsApp untuk menerima bukti transaksi.</p>
              <div className="mt-7">
                <label className="mb-2 block text-sm font-semibold">Nomor WhatsApp</label>
                <input
                  type="tel"
                  placeholder="08xxxxxxxxxx"
                  value={whatsapp}
                  onChange={(e) => setWhatsapp(e.target.value)}
                  className="w-full rounded-xl border border-white/10 bg-white/[0.04] px-4 py-3 outline-none transition focus:border-purple-400"
                />
              </div>
              <div className="mt-7 rounded-2xl border border-white/10 bg-white/[0.03] p-5">
                <p className="mb-4 text-xs font-bold uppercase tracking-widest text-white/30">Order Summary</p>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-white/40">Game</span>
                    <span>{checkoutGame}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/40">Player ID</span>
                    <span>{userId}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/40">Item</span>
                    <span>{selectedAmount}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/40">Payment</span>
                    <span>{selectedPayment}</span>
                  </div>
                  <div className="my-3 h-px bg-white/10" />
                  <div className="flex justify-between text-base">
                    <span className="font-bold">Total</span>
                    <span className="font-bold text-purple-300">{formatRupiah(total)}</span>
                  </div>
                </div>
              </div>
              <div className="mt-5 flex gap-3">
                <button
                  onClick={() => setStep(3)}
                  className="w-1/3 rounded-xl border border-white/10 bg-white/5 px-5 py-3 font-bold"
                >
                  ← Back
                </button>
                <button
                  onClick={submitOrder}
                  className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-purple-500 to-fuchsia-500 px-5 py-3 font-bold transition hover:shadow-lg hover:shadow-purple-500/20"
                >
                  ⚡ Bayar Sekarang
                </button>
              </div>
            </div>
          )}

          {/* SUCCESS */}
          {showSuccess && (
            <div className="py-10 text-center">
              <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-lime-400/10 text-4xl">
                ✓
              </div>
              <h3 className="font-display mt-6 text-3xl font-extrabold">Order Berhasil! 🎉</h3>
              <p className="mx-auto mt-3 max-w-md text-sm leading-7 text-white/45">
                Order kamu berhasil dibuat. Status transaksi bisa kamu cek melalui tracker.
              </p>
              <div className="mt-7 rounded-2xl border border-white/10 bg-white/[0.03] p-5 text-left">
                <div className="flex justify-between text-sm">
                  <span className="text-white/40">Order ID</span>
                  <span className="font-mono text-purple-300">{orderId}</span>
                </div>
                <div className="mt-3 flex justify-between text-sm">
                  <span className="text-white/40">Status</span>
                  <span className="text-lime-300">Processing ⚡</span>
                </div>
              </div>
              <button
                onClick={handleSuccessClose}
                className="mt-6 w-full rounded-xl bg-white px-5 py-3 font-bold text-black"
              >
                Lihat Status Transaksi
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
