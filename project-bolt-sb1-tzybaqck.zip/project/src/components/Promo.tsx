export function Promo() {
  const scrollToGames = () => {
    document.getElementById("games")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section id="promo" className="mx-auto max-w-7xl px-5 py-16 lg:px-8">
      <div className="relative overflow-hidden rounded-3xl border border-purple-400/20 bg-gradient-to-r from-purple-500/15 via-fuchsia-500/10 to-cyan-400/10 p-7 sm:p-10">
        <div className="absolute -right-20 -top-20 h-60 w-60 rounded-full bg-purple-500/20 blur-[80px]" />
        <div className="relative flex flex-col justify-between gap-7 md:flex-row md:items-center">
          <div>
            <span className="text-sm font-bold text-lime-300">✨ DISKON KILAT</span>
            <h2 className="font-display mt-2 text-3xl font-extrabold sm:text-4xl">
              Lagi banyak promo. <span className="text-purple-300">Jangan keduluan.</span>
            </h2>
            <p className="mt-2 max-w-xl text-sm text-white/50">
              Pilih game favoritmu dan cek harga promo yang tersedia hari ini.
            </p>
          </div>
          <button
            onClick={scrollToGames}
            className="shrink-0 rounded-xl bg-white px-6 py-3 font-bold text-black transition hover:scale-105"
          >
            Cek Promo →
          </button>
        </div>
      </div>
    </section>
  );
}
