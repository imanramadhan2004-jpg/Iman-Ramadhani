import { heroFeatures } from "@/data";

export function Hero() {
  const scrollToGames = () => {
    document.getElementById("games")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section className="mesh-bg relative min-h-[720px] overflow-hidden pt-32">
      <div className="hero-grid absolute inset-0" />
      <div className="absolute left-[10%] top-40 h-72 w-72 rounded-full bg-purple-500/10 blur-[100px]" />
      <div className="absolute right-[10%] top-48 h-72 w-72 rounded-full bg-cyan-400/10 blur-[100px]" />

      <div className="relative mx-auto max-w-7xl px-5 py-20 text-center lg:px-8">
        <div className="mx-auto mb-7 inline-flex items-center gap-2 rounded-full border border-purple-400/20 bg-purple-400/10 px-4 py-2 text-sm font-semibold text-purple-300">
          <span className="h-2 w-2 rounded-full bg-lime-400 pulse-dot" />
          INSTANT GAME TOP UP
        </div>

        <h1 className="font-display mx-auto max-w-5xl text-5xl font-extrabold leading-[0.95] tracking-tight sm:text-7xl lg:text-8xl">
          Top Up Tanpa Ribet.
          <br />
          <span className="bg-gradient-to-r from-purple-400 via-fuchsia-400 to-cyan-400 bg-clip-text text-transparent">
            Langsung Gas.
          </span>
        </h1>

        <p className="mx-auto mt-8 max-w-2xl text-base leading-7 text-white/50 sm:text-lg">
          Diamond, UC, VP, Genesis Crystals, dan voucher favoritmu. Proses cepat, harga transparan, no drama.
        </p>

        <div className="mt-9 flex flex-col justify-center gap-3 sm:flex-row">
          <button
            onClick={scrollToGames}
            className="group relative overflow-hidden rounded-2xl bg-purple-500 px-7 py-4 font-bold transition duration-300 hover:-translate-y-1 hover:bg-purple-400 hover:shadow-[0_15px_45px_rgba(168,85,247,.3)]"
          >
            <span className="relative z-10">⚡ Top Up Sekarang</span>
            <span className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/20 to-transparent transition-transform duration-700 group-hover:translate-x-full" />
          </button>
          <button
            onClick={scrollToGames}
            className="rounded-2xl border border-white/10 bg-white/[0.04] px-7 py-4 font-bold transition hover:bg-white/[0.08]"
          >
            Lihat Game →
          </button>
        </div>

        <div className="mx-auto mt-14 grid max-w-3xl grid-cols-3 gap-3">
          {heroFeatures.map((f) => (
            <div key={f.label} className="glass rounded-2xl p-4">
              <div className="text-xl">{f.icon}</div>
              <p className="mt-2 text-xs font-semibold text-white/70 sm:text-sm">{f.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
