export function Footer() {
  return (
    <footer className="border-t border-white/5">
      <div className="mx-auto flex max-w-7xl flex-col justify-between gap-5 px-5 py-10 sm:flex-row lg:px-8">
        <div>
          <div className="font-display text-2xl font-extrabold">
            NEXA<span className="text-purple-400">.</span>
          </div>
          <p className="mt-2 text-sm text-white/30">Top up tanpa ribet. Langsung gas.</p>
        </div>
        <div className="text-sm text-white/30">© 2026 NEXA. Demo UI concept.</div>
      </div>
    </footer>
  );
}
