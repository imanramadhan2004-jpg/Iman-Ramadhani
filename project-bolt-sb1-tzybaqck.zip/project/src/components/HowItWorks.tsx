import { howItWorks } from "@/data";

export function HowItWorks() {
  return (
    <section id="cara-order" className="border-y border-white/5 bg-white/[0.015]">
      <div className="mx-auto max-w-7xl px-5 py-20 lg:px-8">
        <div className="text-center">
          <p className="text-sm font-bold uppercase tracking-widest text-purple-400">Simple Flow</p>
          <h2 className="font-display mt-2 text-4xl font-extrabold">Top Up? Gampang.</h2>
        </div>

        <div className="mt-12 grid gap-5 md:grid-cols-4">
          {howItWorks.map((step) => (
            <div key={step.num} className="glass rounded-3xl p-6">
              <div className={`flex h-12 w-12 items-center justify-center rounded-2xl ${step.bg} text-xl ${step.color}`}>
                {step.num}
              </div>
              <h3 className="font-display mt-5 text-xl font-bold">{step.title}</h3>
              <p className="mt-2 text-sm leading-6 text-white/40">{step.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
