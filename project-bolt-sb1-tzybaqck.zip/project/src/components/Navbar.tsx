import { useUI } from "@/context/UIContext";

export function Navbar() {
  const { openTracker, openCheckout } = useUI();

  const scrollToGames = () => {
    document.getElementById("games")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <header className="fixed top-0 z-40 w-full border-b border-white/5 bg-[#08070d]/80 backdrop-blur-xl">
      <nav className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4 lg:px-8">
        <a href="#" className="font-display text-2xl font-extrabold tracking-tight">
          NEXA<span className="text-purple-400">.</span>
        </a>

        <div className="hidden items-center gap-8 text-sm text-white/60 md:flex">
          <a href="#games" className="transition hover:text-white">Games</a>
          <a href="#promo" className="transition hover:text-white">Promo</a>
          <a href="#cara-order" className="transition hover:text-white">Cara Order</a>
          <a href="#faq" className="transition hover:text-white">FAQ</a>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={openTracker}
            className="hidden rounded-xl border border-white/10 px-4 py-2 text-sm font-semibold text-white/70 transition hover:bg-white/5 hover:text-white sm:block"
          >
            Cek Transaksi
          </button>
          <button
            onClick={scrollToGames}
            className="rounded-xl bg-purple-500 px-4 py-2 text-sm font-bold transition hover:bg-purple-400 hover:shadow-lg hover:shadow-purple-500/20"
          >
            ⚡ Top Up
          </button>
        </div>
      </nav>
    </header>
  );
}
