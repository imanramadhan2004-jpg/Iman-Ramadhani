import type { Game, AmountOption, PaymentMethod, FAQItem, Testimonial } from "@/types";

export const games: Game[] = [
  {
    name: "Mobile Legends",
    category: "mobile",
    currency: "Diamond & Membership",
    startingPrice: 10000,
    gradient: "from-purple-900 to-blue-900",
    shortLabel: "MLBB",
    badge: { text: "🔥 TERLARIS", className: "bg-orange-400 text-black" },
  },
  {
    name: "Free Fire",
    category: "mobile",
    currency: "Diamonds",
    startingPrice: 5000,
    gradient: "from-orange-900 to-red-900",
    shortLabel: "FF",
    badge: { text: "⚡ INSTANT", className: "bg-lime-400 text-black" },
  },
  {
    name: "Genshin Impact",
    category: "mobile",
    currency: "Genesis Crystals",
    startingPrice: 16000,
    gradient: "from-cyan-900 to-blue-900",
    shortLabel: "GENSHIN",
    badge: { text: "✨ POPULER", className: "bg-purple-400 text-black" },
  },
  {
    name: "Valorant",
    category: "pc",
    currency: "Valorant Points",
    startingPrice: 15000,
    gradient: "from-red-900 to-pink-900",
    shortLabel: "VAL",
    badge: { text: "⚡ POPULER", className: "bg-cyan-300 text-black" },
  },
  {
    name: "Roblox",
    category: "mobile",
    currency: "Robux",
    startingPrice: 15000,
    gradient: "from-green-900 to-cyan-900",
    shortLabel: "ROBLOX",
  },
  {
    name: "PlayStation",
    category: "console",
    currency: "PSN Wallet",
    startingPrice: 50000,
    gradient: "from-blue-950 to-indigo-900",
    shortLabel: "PSN",
  },
  {
    name: "Steam Wallet",
    category: "voucher",
    currency: "Steam Wallet Code",
    startingPrice: 12000,
    gradient: "from-slate-900 to-blue-950",
    shortLabel: "STEAM",
  },
  {
    name: "Google Play",
    category: "voucher",
    currency: "Google Play Voucher",
    startingPrice: 10000,
    gradient: "from-green-900 to-blue-900",
    shortLabel: "PLAY",
  },
];

export const amountOptions: AmountOption[] = [
  { label: "86 Diamonds", price: 10000 },
  { label: "172 Diamonds", price: 20000, badge: "BEST VALUE" },
  { label: "257 Diamonds", price: 30000 },
  { label: "344 Diamonds", price: 40000 },
  { label: "429 Diamonds", price: 50000 },
  { label: "706 Diamonds", price: 80000, badge: "🔥 HOT" },
];

export const paymentMethods: PaymentMethod[] = [
  { name: "QRIS", label: "QRIS", icon: "📱", group: "E-Wallet" },
  { name: "GoPay", label: "GoPay", icon: "💚", group: "E-Wallet" },
  { name: "DANA", label: "DANA", icon: "🔵", group: "E-Wallet" },
  { name: "OVO", label: "OVO", icon: "🟣", group: "E-Wallet" },
  { name: "BCA VA", label: "BCA", icon: "🏦", group: "Virtual Account" },
  { name: "BRI VA", label: "BRI", icon: "🏦", group: "Virtual Account" },
  { name: "BNI VA", label: "BNI", icon: "🏦", group: "Virtual Account" },
  { name: "Mandiri VA", label: "Mandiri", icon: "🏦", group: "Virtual Account" },
];

export const faqItems: FAQItem[] = [
  {
    question: "Berapa lama proses top up?",
    answer:
      "Mayoritas transaksi diproses otomatis dalam hitungan detik hingga menit setelah pembayaran terkonfirmasi.",
  },
  {
    question: "Apakah saya perlu memberikan password akun?",
    answer:
      "Tidak. Jangan pernah memberikan password akun game kamu. NEXA hanya membutuhkan informasi yang diperlukan untuk memproses top up.",
  },
  {
    question: "Kalau item belum masuk bagaimana?",
    answer:
      "Cek status transaksi terlebih dahulu. Jika transaksi sudah berhasil tetapi item belum diterima, hubungi support dengan nomor transaksi.",
  },
];

export const testimonials: Testimonial[] = [
  {
    name: "Raka",
    game: "Mobile Legends",
    avatar: "R",
    avatarBg: "bg-purple-500/20",
    message: "Baru pertama nyoba, ternyata masuk cepet banget wkwk. Recommended sih 🔥",
  },
  {
    name: "Dimas",
    game: "Valorant",
    avatar: "D",
    avatarBg: "bg-cyan-400/20",
    message: "Harga jelas, proses sat-set. Nggak perlu ribet chat admin.",
  },
  {
    name: "Alya",
    game: "Genshin Impact",
    avatar: "A",
    avatarBg: "bg-lime-400/20",
    message: "Bayar → tinggal tunggu → masuk. Sesimpel itu 😭✨",
  },
];

export const heroFeatures = [
  { icon: "⚡", label: "Instant Process" },
  { icon: "🔒", label: "Secure Payment" },
  { icon: "💬", label: "Support Ready" },
];

export const howItWorks = [
  { num: "01", title: "Masukkan ID", desc: "Isi User ID dan Zone ID game kamu.", bg: "bg-purple-500/15", color: "text-purple-300" },
  { num: "02", title: "Pilih Item", desc: "Pilih diamond, UC, VP, Robux, atau item lainnya.", bg: "bg-cyan-400/10", color: "text-cyan-300" },
  { num: "03", title: "Bayar", desc: "Pilih metode pembayaran favoritmu.", bg: "bg-lime-400/10", color: "text-lime-300" },
  { num: "04", title: "Done!", desc: "Tunggu sebentar. Item segera dikirim.", bg: "bg-fuchsia-400/10", color: "text-fuchsia-300" },
];

export const gameFilters: { label: string; value: string }[] = [
  { label: "Semua", value: "all" },
  { label: "Mobile", value: "mobile" },
  { label: "PC", value: "pc" },
  { label: "Console", value: "console" },
  { label: "Voucher", value: "voucher" },
];
