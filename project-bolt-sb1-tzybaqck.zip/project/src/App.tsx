import { UIProvider } from "@/context/UIContext";
import { Navbar } from "@/components/Navbar";
import { Hero } from "@/components/Hero";
import { Promo } from "@/components/Promo";
import { GameCatalog } from "@/components/GameCatalog";
import { HowItWorks } from "@/components/HowItWorks";
import { Testimonials } from "@/components/Testimonials";
import { FAQ } from "@/components/FAQ";
import { Footer } from "@/components/Footer";
import { CheckoutModal } from "@/components/CheckoutModal";
import { TransactionTracker } from "@/components/TransactionTracker";
import { Toast } from "@/components/Toast";

function App() {
  return (
    <UIProvider>
      <Navbar />
      <Hero />
      <Promo />
      <GameCatalog />
      <HowItWorks />
      <Testimonials />
      <FAQ />
      <Footer />
      <CheckoutModal />
      <TransactionTracker />
      <Toast />
    </UIProvider>
  );
}

export default App;
